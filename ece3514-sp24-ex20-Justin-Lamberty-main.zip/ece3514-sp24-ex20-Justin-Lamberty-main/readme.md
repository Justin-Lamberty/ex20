[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/HKnF7hHY)
---
title: Exercise 20
---

In this exercise we will implement some more usefull functions on List implementations using Functors.

1. Create a working directory somewhere on your computer. Open your command line terminal and make a working directory. Then change to that directory.

2. Clone the assignment for today. Accept the GitHub classroom invitation. This will automatically add this repository accessible to you and the instructor/TAs with some starter files. You can then clone it to your computer using

	```
	git clone https://github.com/VTECE/ece3514-sp24-ex20-USER.git
	```
	
	where USER is your GitHub username. You may have to enter your GitHub 
	username and password.

3. Implement the missing algorithms in ``algorithms.tpp`` and use then to solve the problems in ``test_algorithms.cpp`` marked TODO.

4. Add the updates to your repository and commit the changes, e.g.

	```
	git add -u
   	git commit -m "implement some more sequential algorithms"
	```
	
5. Use git push to synchronize the repository with that on GitHub

	```git push```
	
	You may have to enter your GitHub username and password again.

6. Submit your Exercise-20 to Gradescopte through your remote GitHub repository. 

You have now completed the exercise.

